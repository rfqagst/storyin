enum AuthState { initial,loading, success, error }
