enum ResultState { idle, loading, noData, hasData, error }
