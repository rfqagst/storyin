enum PostState { idle, loading, success, error }
